//
//  HelloWorldLayer.h
//  Jumpy
//
//  Created by Pepi Zawodsky on 08.11.12.
//  Copyright PSPDFKit 2012. All rights reserved.
//


// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"

// HelloWorldLayer
@interface HelloWorldLayer : CCLayer
{
    CCSprite *player;
    CGPoint velocity;
    CCArray *salads;
}

// returns a CCScene that contains the HelloWorldLayer as the only child
+(CCScene *) scene;

@end
